library(testthat)
library(cvAUC)
library(h2oEnsemble)

test_check("h2oEnsemble")
