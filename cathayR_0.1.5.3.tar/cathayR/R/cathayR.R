#initial 環境
inicathayR<-function(){
if (!require("factoextra")) install.packages("factoextra")
library('factoextra')
if (!require("party")) install.packages("party")
library('party')
if (!require("strucchange")) install.packages("strucchange")
library('strucchange')
if (!require("sandwich")) install.packages("sandwich")
library('sandwich')
if (!require("zoo")) install.packages("zoo")
library('zoo')
if (!require("modeltools")) install.packages("modeltools")
library('modeltools')
if (!require("stats4")) install.packages("stats4")
library('stats4')
if (!require("mvtnorm")) install.packages("mvtnorm")
library('mvtnorm')
if (!require("grid")) install.packages("grid")
library('grid')
if (!require("cluster")) install.packages("cluster")
library('cluster')
if (!require("maxent")) install.packages("maxent")
library('maxent')
if (!require("Hmisc")) install.packages("Hmisc")
library('Hmisc')
if (!require("NLP")) install.packages("NLP")
library('NLP')
if (!require("SparseM")) install.packages("SparseM")
library('SparseM')
if (!require("corrplot")) install.packages("corrplot")
library('corrplot')
if (!require("Formula")) install.packages("Formula")
library('Formula')
if (!require("survival")) install.packages("survival")
library('survival')
if (!require("caret")) install.packages("caret")
library('caret')
if (!require("ggplot2")) install.packages("ggplot2")
library('ggplot2')
if (!require("lattice")) install.packages("lattice")
library('lattice')
if (!require("nnet")) install.packages("nnet")
library('nnet')
if (!require("neuralnet")) install.packages("neuralnet")
library('neuralnet')
if (!require("readr")) install.packages("readr")
library('readr')
if (!require("stats")) install.packages("stats")
library('stats')
if (!require("graphics")) install.packages("graphics")
library('graphics')
if (!require("grDevices")) install.packages("grDevices")
library('grDevices')
if (!require("utils")) install.packages("utils")
library('utils')
if (!require("methods")) install.packages("methods")
library('methods')
if (!require("data.table")) install.packages("data.table")
library('data.table')
if (!require("rpart")) install.packages("rpart")
library('rpart')
if (!require("rpart.plot")) install.packages("rpart.plot")
library('rpart.plot')
if (!require("Matrix")) install.packages("Matrix")
library('Matrix')
if (!require("xgboost")) install.packages("xgboost")
library('xgboost')
}


#找出相關係數及P值轉為矩陣
convCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}

#產出共線性欄位
findCollineList<-function(data,corr_vlaue){
  numeric_data <- as.data.frame(Filter(is.numeric, data)) #篩選型態為numeric的欄位
  correlation <- cor(numeric_data) #計算相關係數
  corrplot(correlation, method='circle') #繪出相關圖
  res2<-rcorr(as.matrix(numeric_data)) #欄位資料轉為矩陣格式
  cor <- convCorrMatrix(res2$r, res2$P) #將相關係數及P值轉為矩陣
  high <- cor[cor$cor>corr_vlaue,] #將高於指定的相關係數欄位列出
  high <- high[order(-high$cor),] #根據相關性排序
  return(high)
}



# 判斷型態資料處理函數
autoDefineCol<-function(data,col.name){
  def_tmp<-NULL
  def_tmp[1]<-as.numeric(is.character(data[[col.name]])) #是否文字
  def_tmp[2]<-as.numeric(is.integer(data[[col.name]])) #是否整數
  def_tmp[3]<-as.numeric(is.numeric(data[[col.name]])) #是否實數
  def_tmp[4]<-as.numeric(inherits(data[[col.name]], what = "Date")) #是否日期
  def_tmp[5]<-as.numeric(is.factor(data[[col.name]])) #是否類別
  result <- try(toupper(data[[col.name]][complete.cases(data[[col.name]])]), silent=TRUE) #移除NULL
  if (class(result) == "try-error") {
    data_tmp<-0
  }else{
    data_tmp<-result
  }
  def_tmp[6]<-as.numeric(length(names(table(data_tmp)))==1) #因子1個
  def_tmp[7]<-as.numeric(sum(grepl('0',data_tmp))>0) #因子有0
  def_tmp[8]<-as.numeric(sum(grepl('1',data_tmp))>0) #因子有1
  def_tmp[9]<-as.numeric(sum(grepl('Y',data_tmp))>0) #因子有Y
  def_tmp[10]<-as.numeric(sum(grepl('N',data_tmp))>0) #因子有N
  def_tmp[11]<-as.numeric(sum(grepl('F',data_tmp))>0) #因子有F
  def_tmp[12]<-as.numeric(sum(grepl('M',data_tmp))>0) #因子有M
  def_tmp[13]<-as.numeric(sum(grepl('[a-zA-Z]',data_tmp))>0) #因子英文字
  def_tmp[14]<-as.numeric(sum(grepl('[0-9]',data_tmp))>0) #因子數字
  def_tmp[15]<-as.numeric(sum(grepl('[a-zA-Z0-9]',data_tmp))>0) #因子有英文字+數字
  def_tmp[16]<-as.numeric(sum(grepl('_IND',col.name))>0) #欄位名稱有_IND
  def_tmp[17]<-as.numeric(sum(grepl('_ID',col.name))>0) #欄位名稱有_ID
  def_tmp[18]<-as.numeric(sum(grepl('IF_',col.name))>0) #欄位名稱有IF_
  def_tmp[19]<-as.numeric(sum(grepl('_CD',col.name))>0) #欄位名稱有_CD
  def_tmp[20]<-as.numeric(sum(grepl('_DT',col.name))>0) #欄位名稱有_DT
  def_tmp[21]<-as.numeric(sum(grepl('_CNT',col.name))>0) #欄位名稱有_CNT
  def_tmp[22]<-as.numeric(sum(grepl('_NUM',col.name))>0) #欄位名稱有_NUM
  def_tmp[23]<-as.numeric(sum(grepl('_AMT',col.name))>0) #欄位名稱有_AMT
  def_tmp[24]<-as.numeric(sum(grepl('_KIND',col.name))>0) #欄位名稱有_KIND
  def_tmp[25]<-as.numeric(sum(grepl('_DAY',col.name))>0) #欄位名稱有_DAY
  def_tmp[26]<-as.numeric(sum(grepl('_TIMES',col.name))>0) #欄位名稱有_TIMES
  def_tmp[27]<-as.numeric(sum(grepl('-',data_tmp))>0) #因子有-
  def_tmp[28]<-as.numeric(length(names(table(data_tmp)))==0) #沒有因子都為NULL
  def_tmp[29]<-as.numeric(length(names(table(data_tmp)))==2) #因子2個
  def_tmp[30]<-as.numeric(length(names(table(data_tmp)))==3) #因子3個
  def_tmp[31]<-as.numeric(length(names(table(data_tmp)))>3) #因子>3個
  def_tmp[32]<-as.numeric(max(data_tmp)==min(data_tmp)) #最大最小一樣
  def_tmp[33]<-as.numeric(sum(grepl('[0-9]',max(data_tmp)))>0) #最大值是數字
  def_tmp[34]<-as.numeric(sum(grepl('[0-9]',min(data_tmp)))>0) #最大值是數字
  def_tmp[35]<-as.numeric(sum(grepl('[a-zA-Z]',max(data_tmp)))>0) #最大值是英文
  def_tmp[36]<-as.numeric(sum(grepl('[a-zA-Z]',min(data_tmp)))>0) #最大值是英文
  def_tmp[37]<-as.numeric(sum(grepl('LEVEL',col.name))>0) #欄位名稱有LEVEL
  def_tmp[38]<-as.numeric(sum(grepl('_LVL',col.name))>0) #欄位名稱有_LVL
  def_tmp[39]<-as.numeric(sum(grepl('-',data_tmp))>0) #因子有- 增加日期特徵用
  def_tmp[40]<-as.numeric(sum(grepl('-',data_tmp))>0) #因子有- 增加日期特徵用
  def_tmp[41]<-as.numeric(sum(grepl('-',data_tmp))>0) #因子有- 增加日期特徵用
  def_tmp[42]<-as.numeric(sum(grepl('_DATE',col.name))>0) #欄位名稱有_DATE
  def_tmp[43]<-as.numeric(length(names(table(data_tmp)))==length(data_tmp)) #因子個數=列數
  def_tmp[44]<-as.numeric(sum(grepl('_POL',col.name))>0) #欄位名稱有_POL
  def_tmp[45]<-as.numeric(mean(data_tmp)>100 && mean(data_tmp)<500) #資料平均>100 <500
  def_tmp[46]<-as.numeric(mean(data_tmp)>40 && mean(data_tmp)<100)  #資料平均>40 <100
  def_tmp[47]<-as.numeric(mean(data_tmp)>10000) #資料平均>1K
  def_tmp[48]<-as.numeric(sum(grepl('AGE',col.name))>0) #欄位名稱有AGE
  def_tmp[49]<-as.numeric(sum(grepl('X1',col.name))>0) #欄位名稱有X1
  def_tmp[50]<-as.numeric(sum(grepl('_NO',col.name))>0) #欄位名稱有_NO
  def_tmp[51]<-as.numeric(sum(grepl('_OPRID',col.name))>0) #欄位名稱有_OPRID
  def_tmp[52]<-as.numeric(sum(grepl('MEMO',col.name))>0) #欄位名稱有_MEMO
  def_tmp[53]<-as.numeric(sum(grepl('_FLAG',col.name))>0) #欄位名稱有_FLAG
  def_tmp[54]<-as.numeric(sum(grepl('_FLG',col.name))>0) #欄位名稱有_FLG
  def_tmp[55]<-as.numeric(sum(grepl('_CODE',col.name))>0) #欄位名稱有_CODE
  def_tmp[56]<-as.numeric(sum(grepl('IS_',col.name))>0) #欄位名稱有IS_
  def_tmp[57]<-as.numeric(sum(grepl('_CAT',col.name))>0) #欄位名稱有_CAT
  def_tmp[58]<-as.numeric(sum(grepl('_PRD',col.name))>0) #欄位名稱有_PRD
  def_tmp[59]<-as.numeric(sum(grepl('_INCOME',col.name))>0) #欄位名稱有_INCOME
  def_tmp[60]<-as.numeric(sum(grepl('_GRADE',col.name))>0) #欄位名稱有_GRADE
  def_tmp[61]<-as.numeric(sum(grepl('_RATE',col.name))>0) #欄位名稱有_RATE
  def_tmp[62]<-as.numeric(sum(grepl('POLICY_NO',col.name))>0) #欄位名稱有POLICY_NO
  def_tmp[63]<-as.numeric(sum(grepl('PROD_ID',col.name))>0) #欄位名稱有PROD_ID
  def_tmp[is.na(def_tmp)]<-0
  return(def_tmp)
}




# 資料型態判斷函數
autoTypeMining<-function(data){
  #載入模型
  load("~/R/ML/TypeModel.rda")
  #建立空的型態探勘矩陣
  type_result<-data.frame()
  col.list<-names(data)
  #進行簡易資料探勘
  for(col.name in col.list){
    print(paste(Sys.time(),"處理欄位",col.name,"型態判斷"))
    dm_set<-autoDefineCol(data,col.name)
    type_result<-rbind(type_result,dm_set)
  }
  #給COL名稱
  colnames(type_result)=c('IS_CHR', 'IS_INT', 'IS_NUME', 'IS_DATE', 'IS_FAC', 'N_1', 'IS_0', 'IS_1', 'IS_Y', 'IS_N', 'IS_F', 'IS_M', 'IS_EN', 'IS_09', 'IS_EN09', 'IS_IND', 'IS_ID', 'IS_IF', 'IS_CD', 'IS_DT', 'IS_CNT', 'IS_NUM', 'IS_AMT', 'IS_KIND', 'IS_DAY', 'IS_TIMES', 'IS_DASH', 'N_0', 'N_2', 'N_3', 'N_3UP', 'IS_SAME', 'IS_MAXN', 'IS_MINN', 'IS_MAXE', 'IS_MINE', 'IS_LEVEL', 'IS_LVL', 'IS_DASH2', 'IS_DASH3', 'IS_DASH4', 'IS_TDATE', 'IS_NROW', 'IS_POL', 'IS_MEAN100', 'IS_MEAN40', 'IS_MEAN1K', 'IS_AGE', 'IS_X1')
  #模型formula
  formula.bpn <- character+Date+factor+integer+numeric ~ IS_CHR	 + IS_INT	 + IS_NUME	 + IS_DATE	 + IS_FAC	 + N_1	 + IS_0	 + IS_1	 + IS_Y	 + IS_N	 + IS_F	 + IS_M	 + IS_EN	 + IS_09	 + IS_EN09	 + IS_IND	 + IS_ID	 + IS_IF	 + IS_CD	 + IS_DT	 + IS_CNT	 + IS_NUM	 + IS_AMT	 + IS_KIND	 + IS_DAY	 + IS_TIMES	 + IS_DASH	 + N_0	 + N_2	 + N_3	 + N_3UP	 + IS_SAME	 + IS_MAXN	 + IS_MINN	 + IS_MAXE	 + IS_MINE  + IS_LEVEL   + IS_LVL    + IS_DASH2   + IS_DASH3   + IS_DASH4    + IS_TDATE   + IS_NROW	 + IS_POL	 + IS_MEAN100	 + IS_MEAN40	 + IS_MEAN1K	 + IS_AGE	 + IS_X1
  #進行預測
  pred <- compute(bpn,type_result)
  # 四捨五入後，變成0/1的狀態
  pred.result <- round(pred$net.result)
  # 把結果轉成data frame的型態
  pred.result <- as.data.frame(pred.result)
  pred.result$sol <- " "
  # 把預測結果轉回sol的型態
  for(i in 1:nrow(pred.result)){
    if(pred.result[i, 1]==1){ pred.result[i, "sol"] <- "character"}
    if(pred.result[i, 2]==1){ pred.result[i, "sol"] <- "Date"}
    if(pred.result[i, 3]==1){ pred.result[i, "sol"] <- "factor"}
    if(pred.result[i, 4]==1){ pred.result[i, "sol"] <- "integer"}
    if(pred.result[i, 5]==1){ pred.result[i, "sol"] <- "numeric"}
  }
  return(pred.result$sol)
}



# 資料探勘函數
autoDataMining<-function(data){
  DM_result<-as.character(data.frame())
  DM_tmp<-NULL
  colnames(data)<-toupper(names(data)) # 欄位名稱轉大寫 避免找不到
  print(paste(Sys.time(),"智能資料探勘開始，樣本資料共記",nrow(data),"筆，",ncol(data),"個欄位。"))
  col.list<-names(data) #擷取所有欄位名稱
  for (col.name in col.list){
    DM_tmp[1]<-as.character(col.name)
    DM_tmp[3]<-sum(is.na(data[[col.name]]))
    DM_tmp[4]<-sum(is.na(data[[col.name]]))/nrow(data)*100
    if(DM_tmp[4]==100){
      DM_tmp[5]<-"欄位所有元素皆為NA"
      DM_tmp[6]<-"欄位內元素包涵：NA"
    } else {
      data_tmp<-toupper(data[[col.name]][complete.cases(data[[col.name]])]) #移除NULL
      DM_tmp[5]<-length(names(table(data_tmp))) #元素個數
      if(as.numeric(DM_tmp[5])<10){
        DM_tmp[6]<-paste("欄位內元素包涵：",gsub(",","，",toString(names(table(data_tmp)))))
      } else {
        DM_tmp[6]<-paste("欄位內元素超過10種以上")
      }
    }
    DM_result<-rbind(DM_result,DM_tmp)
    print(paste(Sys.time(),"完成",col.name,"初步探勘"))
  }
  colnames(DM_result)<-c('COLNAME',	'TYPE',	'NA_NUM',	'NA_RATE',	'NFACTOR',	'MEMO')
  DM_result<-as.data.frame(DM_result)
  DM_result$TYPE<-autoTypeMining(data)
  print(paste(Sys.time(),"完成欄位型態處理"))
  write.table(DM_result, file = "~/R/ML/data_mining.csv",row.names = F,sep = ",")
  print(paste(Sys.time(),"儲存探勘結果 data_mining.csv"))
  return(DM_result)
}



# 使用涵數autoDataMining()即可進行資料探勘，並儲存探勘結果在~/R/ML/data_mining.csv
# 請與實際資料筆對後，進行資料型態轉換


# 輸入資料、欄位名稱及型態 可以智能轉換並產出尚需智能處理的函數
autoTypeConv<-function(data,col.list,type){
  sol<-cbind(as.vector(col.list),as.vector(type))
  sol<-as.data.frame(sol) #讀取資料欄位及轉換結果
  n<-nrow(sol)
  arti<-NULL
  for( i in 1:n) {
    if(sol[i,2]=='character'){
      data[[as.character(sol[i,1])]]<-as.character(data[[as.character(sol[i,1])]])
      print(paste(Sys.time(),"欄位名稱：",as.character(sol[i,1]),"轉換成 character 型態"))
    } else if (sol[i,2]=='integer'){
      data[[as.character(sol[i,1])]]<-as.integer(data[[as.character(sol[i,1])]])
      print(paste(Sys.time(),"欄位名稱：",as.character(sol[i,1]),"轉換成 integer 型態"))
    } else if (sol[i,2]=='Date' || sol[i,2]=='date'){
      data[[as.character(sol[i,1])]]<-as.Date(data[[as.character(sol[i,1])]])
      print(paste(Sys.time(),"欄位名稱：",as.character(sol[i,1]),"轉換成 Date 型態"))
    } else if (sol[i,2]=='numeric'){
      data[[as.character(sol[i,1])]]<-as.numeric(data[[as.character(sol[i,1])]])
      print(paste(Sys.time(),"欄位名稱：",as.character(sol[i,1]),"轉換成 numeric 型態"))
    } else if (sol[i,2]=='factor'){
      data[[as.character(sol[i,1])]]<-as.factor(data[[as.character(sol[i,1])]])
      print(paste(Sys.time(),"欄位名稱：",as.character(sol[i,1]),"轉換成 factor 型態"))
    } else{
      arti<-rbind(arti,as.character(sol[i,1]))
    }
  }
  print(paste(Sys.time(),"欄位轉換處理完成"))
  print("尚有以下欄位需人工處理:")
  print(list(arti))
  return(data)
}


# 離群值處理函數
autoTransOutlier <- function(data, col_name) {
  col_name<-as.character(col_name)
  data_tmp <- data[[col_name]]
  no_na <- sum(!is.na(data_tmp)) #非NA資料筆數
  na_num <- sum(is.na(data_tmp)) #NA資料筆數
  mean_1 <- mean(data_tmp, na.rm = T) #NA資料平均
  par(mfrow=c(2, 2), oma=c(0,0,3,0))
  boxplot(data_tmp, main="With outliers") #帶離群值的盒型圖
  hist(data_tmp, main="With outliers", xlab=NA, ylab=NA) #帶離群值的直方圖
  outlier <- boxplot.stats(data_tmp)$out #顯示離群值
  mean_o <- mean(outlier) #計算離群值平均
  data_tmp_o <- ifelse(data_tmp %in% outlier, NA, data_tmp) #將離群值取代為NA
  boxplot(data_tmp_o, main="Without outliers")
  hist(data_tmp_o, main="Without outliers", xlab=NA, ylab=NA)
  title("Outlier Check", outer=TRUE)
  na_num_2 <- sum(is.na(data_tmp_o)) #轉換後NA資料筆數
  print(paste("Outliers identified:", na_num_2 - na_num)) #轉換後-轉換前=離群轉NA數
  print(paste("Propotion (%) of outliers:", round((na_num_2 - na_num) / no_na*100, 2)))
  print(paste("Mean of the outliers:", round(mean_o, 2)))
  mean_2 <- mean(data_tmp_o, na.rm = T)
  print(paste("Mean without removing outliers:", round(mean_1, 2)))
  print(paste("Mean if remove outliers:", round(mean_2, 2)))
  response <- readline(prompt=paste("是否將",col_name,"離群值取代為 NA? [yes/no]: "))
  if(response == "y" | response == "yes"){
    data[[col_name]]<-data_tmp_o
    print("離群值處理成功")
    return(data)
  } else{
    print("Nothing changed")
    return(data)
  }
}



# 離群值統計
autoOutlier <- function(data, col_name) {
  col_name<-as.character(col_name)
  data_tmp <- data[[col_name]]
  no_na <- sum(!is.na(data_tmp)) #非NA資料筆數
  na_num <- sum(is.na(data_tmp)) #NA資料筆數
  mean_1 <- mean(data_tmp, na.rm = T) #NA資料平均
  par(mfrow=c(2, 2), oma=c(0,0,3,0))
  boxplot(data_tmp, main="With outliers") #帶離群值的盒型圖
  hist(data_tmp, main="With outliers", xlab=NA, ylab=NA) #帶離群值的直方圖
  outlier <- boxplot.stats(data_tmp)$out #顯示離群值
  mean_o <- mean(outlier) #計算離群值平均
  data_tmp_o <- ifelse(data_tmp %in% outlier, NA, data_tmp) #將離群值取代為NA
  boxplot(data_tmp_o, main="Without outliers")
  hist(data_tmp_o, main="Without outliers", xlab=NA, ylab=NA)
  title("Outlier Check", outer=TRUE)
  na_num_2 <- sum(is.na(data_tmp_o)) #轉換後NA資料筆數
  print(paste("Outliers identified:", na_num_2 - na_num)) #轉換後-轉換前=離群轉NA數
  print(paste("Propotion (%) of outliers:", round((na_num_2 - na_num) / no_na*100, 2)))
  print(paste("Mean of the outliers:", round(mean_o, 2)))
  mean_2 <- mean(data_tmp_o, na.rm = T)
  print(paste("Mean without removing outliers:", round(mean_1, 2)))
  print(paste("Mean if remove outliers:", round(mean_2, 2)))
}





# 計算最小上界
findMinUpBound<-function(data,upound){
  if(data>=upound){
    return(upound)
  } else{
    return(data)
  }
}




# 整數缺失值處理函數 1.全為同值或NA則刪除 2.缺失高達50%補0 3.缺失服從卡方補值 否則補0
missValueInt<-function(data,col.name){
  print(paste(Sys.time(),"整數欄位補值處理",col.name))
  data_tmp<-data[[col.name]][complete.cases(data[[col.name]])]
  rng<-max(data_tmp) - min(data_tmp)
  if(rng==-Inf || rng==0  ){
    print(paste(Sys.time(),"整數欄位因子皆相同為",data_tmp[1],"，無分析意義，欄位刪除處理",col.name))
    data<-data[!names(data) %in% col.name]
  } else if (rng!=0 && sum(is.na(data[[col.name]]))/length(data[[col.name]])>0.5){
    print(paste(Sys.time(),"整數欄位缺失值補0處理 缺失值高達",sum(is.na(data[[col.name]]))/length(data[[col.name]])*100,"% 建議不使用",col.name))
    data[[col.name]][is.na(data[[col.name]])==T]<-0
  } else {
    data_tmp<-as.numeric(scale(data_tmp)^2)
    chisq_tmp<-rchisq(length(data_tmp),1)
    if(chisq.test(data.frame(data_tmp,chisq_tmp))$p.value>0.05){
      print(paste(Sys.time(),"整數欄位服從卡方分配 欄位補值處理",col.name))
      data[[col.name]][is.na(data[[col.name]])==T]<-round(sqrt(rchisq(1,1))*sd(data_tmp)+mean(data_tmp))
    } else{
      print(paste(Sys.time(),"整數欄位缺失值補0處理",col.name))
      data[[col.name]][is.na(data[[col.name]])==T]<-0
    }

  }
  return(data)
}



# 實數缺失值處理函數 1.全為同值或NA則刪除 2.缺失高達50%補0 3.缺失服從常態補值 否則補0
missValueNum<-function(data,col.name){
  data_tmp<-toupper(data[[col.name]][complete.cases(data[[col.name]])])
  print(paste(Sys.time(),"實數欄位補值處理",col.name))
  data_tmp<-data[[col.name]][complete.cases(data[[col.name]])]
  rng<-max(data_tmp) - min(data_tmp)
  if(rng==-Inf || rng==0  ){
    print(paste(Sys.time(),"實數欄位因子皆相同為",data_tmp[1],"，無分析意義，欄位刪除處理",col.name))
    data<-data[!names(data) %in% col.name]
  } else if (rng!=0 && sum(is.na(data[[col.name]]))/length(data[[col.name]])>0.5){
    print(paste(Sys.time(),"實數欄位缺失值補0處理，缺失值高達",sum(is.na(data[[col.name]]))/length(data[[col.name]])*100,"% 建議不使用",col.name))
    data[[col.name]][is.na(data[[col.name]])==T]<-0
  } else {
    if(shapiro.test(sample(data_tmp,findMinUpBound(length(data_tmp),5000)))$p.value>0.05){
      print(paste(Sys.time(),"實數欄位服從常態分配 欄位補值處理",col.name))
      data[[col.name]][is.na(data[[col.name]])==T]<-rnorm(1,mean(data_tmp),sd(data_tmp))
    } else{
      print(paste(Sys.time(),"實數欄位缺失值補0處理",col.name))
      data[[col.name]][is.na(data[[col.name]])==T]<-0
    }

  }
  return(data)
}




# 類別缺失值處理函數 1.全為同值或NA則刪除
missValueFac<-function(data,col.name){
  print(paste(Sys.time(),"類別欄位補值處理",col.name))
  if(sum(is.na((data[[col.name]])))=='0'){
    print(paste(Sys.time(),"類別欄位無缺失值",col.name))

  } else {
    data_tmp<-as.factor(toupper(data[[col.name]][complete.cases(data[[col.name]])]))
    switch(as.character(nlevels(data_tmp)),
           '0'={ #全為NA
             print(paste(Sys.time(),"類別欄位因子皆相同為",data_tmp[1],"欄位刪除處理",col.name))
             data<-data[!names(data) %in% col.name]
           },
           '1'={ #為FLG格式 補N/0
             if(levels(data_tmp)=='1'){
               print(paste(Sys.time(),"類別欄位值為0/1，缺失值補0處理",col.name))
               levels(data[[col.name]])<-c(levels(data[[col.name]]),'0')
               data[[col.name]][is.na(data[[col.name]])==T]<-'0'
             } else if(levels(data_tmp)=='Y'){
               print(paste(Sys.time(),"類別欄位值為Y/N，缺失值補N處理",col.name))
               levels(data[[col.name]])<-c(levels(data[[col.name]]),'N')
               data[[col.name]][is.na(data[[col.name]])==T]<-'N'
             } else {
               print(paste(Sys.time(),"類別欄位值FLG定義有問題，不為0/1或Y/N，欄位先補0處理",col.name))
               levels(data[[col.name]])<-c(levels(data[[col.name]]),'0')
               data[[col.name]][is.na(data[[col.name]])==T]<-'0'
             }
           },
           '2'={ #為FLG格式 分析缺失狀況
             factor.flg<-sort(levels(data_tmp),decreasing=T)[1] # 取類別最大值判斷
             na_rate<-sum(is.na(data[[col.name]]))/length(data[[col.name]]) #缺失比例
             switch(as.character(na_rate>=0.5), #判斷NA欄位是否過多 過多則補N/0
                    'TRUE'={
                      if(factor.flg=='1'){
                        print(paste(Sys.time(),"類別欄位值為0/1，欄位缺失值高達",na_rate*100,"% 欄位補0處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-'0'
                      } else if(factor.flg=='Y'){
                        print(paste(Sys.time(),"類別欄位值為Y/N，欄位缺失值高達",na_rate*100,"% 欄位補N值處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-'N'
                      } else if(factor.flg=='M'){
                        print(paste(Sys.time(),"類別欄位值為M/F，欄位缺失值高達",na_rate*100,"% 欄位補隨機值處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-sample(data_tmp,1,replace=T)
                      }else {
                        print(paste(Sys.time(),"類別欄位值FLG定義有問題，不為0/1或Y/N，欄位缺失值高達",na_rate*100,"% 欄位先補隨機值處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-sample(data_tmp,1,replace=T)
                      }
                    }, #ㄧ般情況 根據類別分配補值
                    {
                      if(factor.flg=='1'){
                        print(paste(Sys.time(),"類別欄位值為0/1，欄位補0處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-'0'
                      } else if(factor.flg=='Y'){
                        print(paste(Sys.time(),"類別欄位值為Y/N，欄位補N處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-'N'
                      } else if(factor.flg=='M'){
                        print(paste(Sys.time(),"類別欄位值為M/F，欄位補隨機值處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-sample(data_tmp,1,replace=T)
                      }else {
                        print(paste(Sys.time(),"類別欄位值FLG定義有問題 欄位先補隨機值處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-sample(data_tmp,1,replace=T)
                      }
                    }

             )
           },
           {
             factor.flg<-sort(levels(data_tmp))[1] # 取類別最小值判斷
             na_rate<-sum(is.na(data[[col.name]]))/length(data[[col.name]]) #缺失比例
             switch(as.character(na_rate>=0.5),
                    'TRUE'={
                      if(factor.flg=='0'){
                        print(paste(Sys.time(),"類別欄位值為多類別，欄位缺失值高達",na_rate*100,"% 欄位補0處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-'0'
                      } else if(factor.flg=='N'){
                        print(paste(Sys.time(),"類別欄位值為多類別，欄位缺失值高達",na_rate*100,"% 欄位補N值處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-'N'
                      } else {
                        print(paste(Sys.time(),"類別欄位為多類別，欄位缺失值高達",na_rate*100,"% 欄位先補隨機值處理",col.name))
                        data[[col.name]][is.na(data[[col.name]])==T]<-sample(data_tmp,1,replace=T)
                      }
                    },
                    {
                      print(paste(Sys.time(),"類別欄位值為多類別，欄位先補隨機值處理",col.name))
                      data[[col.name]][is.na(data[[col.name]])==T]<-sample(data_tmp,1,replace=T)
                    }
             )
           }
    )
  }
  return(data)
}





# 缺失值處理函數
autoTransMissValue<- function(data,date_method='del'){
  if(is.data.frame(data)==T){
    print("資料集為正確data frame型態")
    for(col.name in names(data)){
      switch(class(data[[col.name]]),
             character={
               print(paste(Sys.time(),"字串欄位刪除處理",col.name))
               data<-data[!names(data) %in% col.name] #字串欄位做刪除處理
             },
             Date={
               if(date_method=='del'){
                 print(paste(Sys.time(),"日期欄位刪除處理",col.name))
                 data<-data[!names(data) %in% col.name]
               } else if(date_method=='add') {
                 print(paste(Sys.time(),"日期欄位補值處理",col.name))
                 if (sum(is.na(data[[col.name]]))/length(data[[col.name]])>0.5){
                   print(paste(Sys.time(),"日期欄位缺失值高達",sum(is.na(data[[col.name]]))/length(data[[col.name]])*100,"% 建議不使用",col.name))
                   data[[col.name]][is.na(data[[col.name]])==T]<-'9999-12-31'
                 } else {
                   data[[col.name]][is.na(data[[col.name]])==T]<-'9999-12-31'
                 }
               } else{
                 stop("日期欄位處理方式未指定或不正確")
               }
             },
             integer={
               data<-missValueInt(data,col.name)
             },
             numeric={
               data<-missValueNum(data,col.name)
             },
             factor={
               data<-missValueFac(data,col.name)
             },
             {
               stop(paste(Sys.time(),"資料欄位有異常",col.name))
             }
      )
    }
    for(col.name in names(data)){
      if(sum(is.na(data[[col.name]]))>0)
        print(paste(col.name,"尚有空值需人工修正"))
    }
    print("缺失值自動化處理完成")
    return(data)
  } else {
    stop("資料集錯誤，不是data frame型式")
  }
}

#剔除補完缺失值後 整欄元素一樣的欄位
removeRepFac<-function(data){
  tmp<-NULL
  for(col.name in  names(data)){
    data_tmp<-data[[col.name]]
    if(length(names(table(data_tmp)))==1){
      tmp<-rbind(tmp,col.name)
      print(paste(Sys.time(),"欄位內皆同一元素，刪除處理",col.name))
    }
  }
  remove<- names(data)  %in% as.character(tmp)
  data<-data[!remove]
  return(data)
}

#智能階層式分群函數，分群群數預設為2,計算silhouette 預設no
autoHierClust <- function(data, distance, method,cut_group=2,calcusil='no'){
  switch(distance,
         binary={
           d  <- dist(data, method = "binary")
           hc <- hclust(d, method = method)
         },
         euclidean={
           d  <- dist(data, method = "euclidean")
           hc <- hclust(d, method = method)
         },
         gower={
           d  <- daisy(data, metric = "gower") #透過Daisy函數計算gower距離矩陣
           hc <- hclust(d, method = method)
         }
  )
  plot(hc, cex = 0.6, hang = -1)	# 畫出樹狀圖
  cluster <- cutree(hc, k = cut_group) # 依樹狀圖結構嘗試分成n群
  rect.hclust(hc, k = cut_group, border = c("red", "blue", "green", "orange"))  # 樹狀圖上匡出每群分佈
  print("個群資料數量：")
  print(table(cluster))
  print(hc)
  if(calcusil=='yes'|calcusil=='Y'){
    print("進行silhouette計算")
    sil <- silhouette(cluster, d) #把分群演算法、距離計算方法丟入silhouette函數
    plot(fviz_silhouette(sil)) #畫出silhouette圖
    return(cluster)
  }else {
    print("不進行silhouette計算")
    return(cluster)
  }
}


#超出全為NULL的欄位名稱
findNullCol<-function(data){
  col.list<-names(data)
  result<-NULL
  for( col in col.list){
    print(paste(Sys.time(),"判斷欄位 ",col))
    if (sum(is.na(data[[col]]))==nrow(data)){
      result<-rbind(result,col)
    } else {
      next
    }
  }
  return(result)
}



# 將ABT資料進行分檻處理
autoStatTable<-function(data){
  data = data.frame(data)
  result = data.frame()
  print(paste(Sys.time(), "進行變數主成分處理"))
  col_list = names(data)
  for( col in col_list){
    print(paste(Sys.time(), "處理欄位",col))
    if(class(data[[col]]) == 'numeric' | class(data[[col]]) == 'integer'){
      # 提取統計量
      stat=as.vector(summary(data[[col]]))
      result = rbind(result,data.frame(COLNAME=col,TYPE=class(data[[col]]) , MIN=stat[1], QU1=stat[2], MID=stat[3], MEAN= stat[4], QU3=stat[5], MAX=stat[6]))
    }
    else {
      next
    }
  }
  print(paste(Sys.time(), "處理完成"))
  return(result)
}

# 從樣本資料與變數資料表 找出變數等級
autoVarGrade<-function(data,stattable){
  print(paste(Sys.time(), "進行變數分級處理"))
  stattable = as.data.frame(stattable)
  data_tmp = data[names(data) %in% as.character(stattable$COLNAME)] # 能進行比較的欄位
  col_list = names(data_tmp)
  for(col in col_list){
    print(paste(Sys.time(), "處理欄位",col))
    stat = stattable[stattable$COLNAME==col,]
    if(data_tmp[[col]] <= stat$QU1){
      stattable[stattable$COLNAME==col,'GD'] = "低於其他75%的案件"
      stattable[stattable$COLNAME==col,'LV'] = 1
    } else if(between(data_tmp[[col]],stat$QU1,stat$MID)){
      stattable[stattable$COLNAME==col,'GD'] = "低於其他50%的案件"
      stattable[stattable$COLNAME==col,'LV'] = 2
    } else if(between(data_tmp[[col]],stat$MID,stat$QU3)){
      stattable[stattable$COLNAME==col,'GD'] = "高於其他50%的案件"
      stattable[stattable$COLNAME==col,'LV'] = 3
    } else if(between(data_tmp[[col]],stat$QU3,stat$MAX)){
      stattable[stattable$COLNAME==col,'GD'] = "高於其他75%的案件"
      stattable[stattable$COLNAME==col,'LV'] = 4
    } else if(data_tmp[[col]] > stat$MAX){
      stattable[stattable$COLNAME==col,'GD'] = "高於其他99%的案件"
      stattable[stattable$COLNAME==col,'LV'] = 5
    }
  }
  print(paste(Sys.time(), "處理完成"))
  return(stattable)
}

# 針對XGBoost模型進行預測
predCarUW<-function(testing_data,xgmodel){
  if(class(xgmodel)!='xgb.Booster'){
    print(paste(Sys.time(), "Model型態有誤 請重新確認"))
    break
  }
  print(paste(Sys.time(), "進行XGBoost模型預測"))
  testing_data = as.data.frame(testing_data)
  m=3
  xdata = model.matrix(~.-1,testing_data)
  Ypred = predict(xgmodel,xdata)
  Ypred = t(matrix(Ypred,m,length(Ypred)/m))
  Ypred = c('H','L','M')[max.col(Ypred)]
  print(paste(Sys.time(), "模型預測風險等級",Ypred))
  print(paste(Sys.time(), "進行主成分分析"))
  imp = xgb.importance(names(testing_data),model=xgmodel)
  print(head(imp))
  result = list(Ypred=Ypred,imp=imp)
  print(paste(Sys.time(), "預測完畢"))
  return(result)
}

# 從主成分資料表與變數資料表 找出風險指標
autoVarPCA<-function(imp,gdtable){
  print(paste(Sys.time(), "風險指標分析"))
  imp = as.data.frame(imp)
  gdtable = as.data.frame(gdtable)
  imp_index = imp$Feature %in% gdtable$COLNAME
  x_table = data.frame(COLNAME=imp[imp_index,]$Feature,GAIN=imp[imp_index,]$Gain)
  y_table = data.frame(COLNAME=gdtable$COLNAME,GD=gdtable$GD,LV=gdtable$LV,MID=gdtable$MID,MEAN=gdtable$MEAN)
  result = merge(x=x_table,y=y_table,by = "COLNAME", all.x = TRUE)
  result = result[order(result$LV, result$GAIN, decreasing = T),]
  return(result)
}




# 車體險模型資料處理 批次
batchGroup.cardataprocess <- function(dataset){
  print(paste(Sys.time(),"開始車體險模型資料處理"))
  colnames(dataset)<-toupper(names(dataset))
  DM_result=read.csv("/home/9400200/public/automobile/model/automobile_model_datatype.csv")
  dataset<-autoTypeConv(dataset,DM_result$COLNAME,DM_result$TYPE)
  # 剔除缺少重要變數資料
  missdata=Reduce(union,list(which(is.na(dataset$INS_MARRIAGE)),
                             which(is.na(dataset$APC_RELATION_INS)),
                             which(is.na(dataset$APC_SEX))))
  if(length(missdata)>0){
    print(paste(Sys.time(),"部份資料因缺少INS_MARRIAGE、APC_RELATION_INS、APC_SEX等重要欄位，將進行剔除"))
    # write.table(dataset[missdata,'CONTRACT_NO'], file = "/home/9400200/public/automobile/MISSIMPORTANCE.TXT",row.names = F,sep = ",")
    # print(paste(Sys.time(),"缺少資料的契約編號已輸出 MISSIMPORTANCE.TXT 檔"))
    dataset=dataset[-missdata,]
    print(paste(Sys.time(),"移除缺少重要變數資料，占",round(length(missdata)/nrow(dataset),3),"%"))
  }
  # 部分資料補值
  print(paste(Sys.time(),"資料遺失值處理"))
  # dataset$IS_ADD_OUTFIT[is.na(dataset$IS_ADD_OUTFIT)]<-0
  levels(dataset$IS_ADD_OUTFIT) <- c(levels(dataset$IS_ADD_OUTFIT), 0)
  dataset[which(is.na(dataset[,'IS_ADD_OUTFIT'])),'IS_ADD_OUTFIT']=0
  return(dataset)
}


# 批次 車體險核保模型
batchGroup.carmodel<-function(dataset){
  # 跑batch腳本
  print(paste(Sys.time(),"開始模型運算"))
  print(paste(Sys.time(),"進行資料分群處理"))
  dataset[,'NO']=1:nrow(dataset) # 標序列
  d1=subset(dataset,dataset$IS_CONTINUE_POLICY=='0' & dataset$VEHICLE_KIND_NO %in% c('03','07'))
  d2=subset(dataset,dataset$IS_CONTINUE_POLICY=='1' & dataset$VEHICLE_KIND_NO %in% c('03','07'))
  d3=subset(dataset,dataset$IS_CONTINUE_POLICY=='0' & !(dataset$VEHICLE_KIND_NO %in% c('03','07')))
  d4=subset(dataset,dataset$IS_CONTINUE_POLICY=='1' & !(dataset$VEHICLE_KIND_NO %in% c('03','07')))
  print(paste(Sys.time(),'第一群有',dim(d1)[1],'筆資料'))
  print(paste(Sys.time(),'第二群有',dim(d2)[1],'筆資料'))
  print(paste(Sys.time(),'第三群有',dim(d3)[1],'筆資料'))
  print(paste(Sys.time(),'第四群有',dim(d4)[1],'筆資料'))
  print(paste(Sys.time(),'開始載入模型檔'))
  # 載入模型檔
  model_group1 <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group1")
  model_group2 <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group2")
  model_group3 <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group3")
  model_group4 <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group4")
  print(paste(Sys.time(),'篩選各群所需欄位'))
  d1=d1[,which(colnames(d1) %in% c(model_group1$x,'NO'))]
  d2=d2[,which(colnames(d2) %in% c(model_group2$x,'NO'))]
  d3=d3[,which(colnames(d3) %in% c(model_group3$x,'NO'))]
  d4=d4[,which(colnames(d4) %in% c(model_group4$x,'NO'))]
  # 進行預測
  result=NULL
  data_no=NULL
  for(i in 1:4){
    print(paste(Sys.time(),'進行第',i,'群預測'))
    tmp=get(paste0('d',i))
    # 保留續列資訊
    data_no=c(data_no,tmp[,ncol(tmp)])
    # 排除序列欄位
    test=tmp[,-ncol(tmp)]
    if(nrow(test)!=0){
      test=as.h2o(test)
      perf_t <- predict(get(paste0('model_group',i)), newdata = test)
      result=rbind(result,as.data.frame(perf_t$pred))
    }
  }
  dim(result)
  result=cbind(result,data_no)
  # 根據序列排回
  result=result[order(result$data_no),]
  print(paste(Sys.time(),'模型預測完成'))
  return(data.frame(PRED=result$predict,RISK_PROB=result$p1))
}



# 單筆 車體險核保模型
one.carmodel<-function(dataset,script){
  # 跑one腳本
  print(paste(Sys.time(),"開始模型運算"))
  switch(script,
         'group1'={
           print(paste(Sys.time(),"資料為第 1 群"))
           model_one <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group1")
         },
         'group2'={
           print(paste(Sys.time(),"資料為第 2 群"))
           model_one <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group2")
         },
         'group3'={
           print(paste(Sys.time(),"資料為第 3 群"))
           model_one <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group3")
         },
         'group4'={
           print(paste(Sys.time(),"資料為第 4 群"))
           model_one <- h2o.load_ensemble(path = "/home/9400200/public/automobile/model/h2o-ensemble-model-group4")
         },
         {
           print(paste(Sys.time(),"發生未預期錯誤"))
           break
         }
  )
  dataset=dataset[,which(colnames(dataset) %in% c(model_one$x))]
  test=as.h2o(dataset)
  print(paste(Sys.time(),"開始模型預測"))
  perf_t <- predict(model_one, newdata = test)
  result <- as.data.frame(perf_t$pred)
  return(data.frame(PRED=result$predict,RISK_PROB=result$p1))
}



